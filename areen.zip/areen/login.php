<?php
    $_SERVER="127.0.0.1";
    $username="root";
    $password=""; 
    $database="user_database";

    $connect=mysqli_connect($_SERVER,$username,$password,$database);

    if(!$connect){
        die("connection to this database is failed due to" . mysqli_connect_error());
    }

    $First_Name=$_POST['fname'];
    $Last_Name=$_POST['lname'];
    $Username=$_POST['email'];
    $password=$_POST['pwd'];
    $confrim_password=$_POST['pass'];
    // $Phone_Number=$_POST['phone'];

    if($password==$confrim_password){
        $sql="INSERT INTO `user_information` ('id', `First Name`, `Last Name`, `Username`, `password`) VALUES ('1', '$First_Name', '$Last_Name', '$Username', '$password')";
        // $connect->query($sql);
        if (mysqli_query($connect, $sql)) {
            echo "New record created successfully";
          } else {
            echo "Error: " . $sql . "<br>" . mysqli_error($connect);
          }
    }
    else
    {
        echo("enter the password and confirm password correctly");
    }
    $connect->close();  
?>







<!DOCTYPE html>
<html lang="en" >
<head>
  <meta charset="UTF-8">
  <title> Login Screen</title>
  <link rel="stylesheet" href="./style-1.css">
 
</head>
<body>
<div  >
    <form class="controls" action="login_page.html" method="POST">
        <label type="fname" >First Name :</label>
        <input type="text" id="fname" name="fname"><br>
        <label for="lname">Last Name :</label>
        <input type="text" id="lname" name="lname"><br>
        <label for="email">Username :</label>
        <input type="text" id="email" name="email"><br>
        <label for="pwd">Password:</label>
        <input type="password" id="pwd" name="pwd"><br>
        <label for="pass">Confrim Password:</label>
        <input type="password" id="pass" name="pass"><br>
        <input type="button" id="button" name="button">
        <button>submit</button>
    </form>
</div>
<div id="particles-js"></div>

  
<script src='https://code.jquery.com/jquery-1.11.1.min.js'></script><script  src="./script.js"></script>

</body>
</html>
